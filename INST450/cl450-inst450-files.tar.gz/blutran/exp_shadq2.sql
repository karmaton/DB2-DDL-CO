
set current degree 'ANY';

set current explain mode yes;
set current maintained table types for optimization replication ;
set current refresh age 500 ;


SELECT BR.branch_name , sum(HISTORY.balance) as br_balance, count(*) as br_trans 
   FROM ROWORG.HISTORY AS HISTORY, roworg.branch as BR
   WHERE HISTORY.BRANCH_ID between 10 and 20
   and HISTORY.BRANCH_ID = BR.BRANCH_ID
   GROUP BY br.BRANCH_NAME
   ORDER BY br.BRANCH_NAME ASC ;

set current explain mode no;

