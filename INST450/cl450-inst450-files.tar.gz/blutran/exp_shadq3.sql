
set current degree 'ANY';

set current explain mode explain;
set current maintained table types for optimization replication ;
set current refresh age any ;


SELECT acct.acct_grp, sum(acct.balance) as grp_balance, count(*) as grp_trans 
   FROM ROWORG.acct as acct
   WHERE acct.acct_grp > 50 
   GROUP BY acct.acct_grp
   ORDER BY acct.acct_grp ASC ;

set current explain mode no;

