-------------
--#SET ROWS_OUT 5
--#SET PERF_DETAIL 1
--

set current degree 'ANY';
set current maintained table types for optimization replication ;
set current refresh age ANY ;

SELECT HISTORY.BRANCH_ID, sum(HISTORY.balance) as br_balance, count(*) as br_trans 
   FROM ROWORG.HISTORY AS HISTORY
   WHERE HISTORY.BRANCH_ID between 10 and 20
   GROUP BY HISTORY.BRANCH_ID
   ORDER BY HISTORY.BRANCH_ID ASC ;

SELECT acct.acct_grp, sum(acct.balance) as grp_balance, count(*) as grp_trans 
   FROM ROWORG.acct as acct
   WHERE acct.acct_grp > 50 
   GROUP BY acct.acct_grp
   ORDER BY acct.acct_grp ASC ;

SELECT BR.branch_name , sum(HISTORY.balance) as br_balance, count(*) as br_trans 
   FROM ROWORG.HISTORY AS HISTORY, roworg.branch as BR
   WHERE HISTORY.BRANCH_ID between 10 and 20
   and HISTORY.BRANCH_ID = BR.BRANCH_ID
   GROUP BY br.BRANCH_NAME
   ORDER BY br.BRANCH_NAME ASC ;

--#COMMENT CHECK STATS
SELECT pool_col_l_reads, pool_data_l_reads, pool_index_l_reads , 
  ( pool_col_l_reads + pool_data_l_reads + pool_index_l_reads ) as total_l_reads
   from table(mon_get_connection(null,-1)) as con 
  where application_name = 'db2batch'
 ;


