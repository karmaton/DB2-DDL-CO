update roworg.history 
 set balance = balance + 1
 where teller_id between 10 and 15 ;

select 
varchar(tabname,20) as table,
varchar(tabschema,12) as schema,
rows_read, rows_updated, rows_deleted, rows_inserted 
from table(mon_get_table('ROWORG',NULL,-2)) as t1 
order by tabname ;

