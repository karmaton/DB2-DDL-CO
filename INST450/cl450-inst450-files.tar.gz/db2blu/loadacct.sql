load from acct.del of del messages loadacctc.msg replace into colorg.acct ;

