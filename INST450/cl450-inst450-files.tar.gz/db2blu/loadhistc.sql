load from histbranch.del of del messages loadchist.msg replace into colorg.historyc ;

