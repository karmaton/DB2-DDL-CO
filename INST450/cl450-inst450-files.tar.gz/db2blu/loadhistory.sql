load from histdata.del of del messages loadhist1.msg replace into colorg.history ;

