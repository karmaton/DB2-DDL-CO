load from branch.del of del messages loadbranch.msg replace into COLORG.branch ;

load from teller.del of del messages loadteller.msg replace into COLORG.teller ;

